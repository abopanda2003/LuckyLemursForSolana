module.exports = {
  jwtSecret: process.env.JWT_SECRET || '8e2fa57e-4822-47e9-896d-483556cf3378'
};