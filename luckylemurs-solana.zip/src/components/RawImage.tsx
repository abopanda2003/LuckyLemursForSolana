import React from "react";

export default function RawImage(props: any) {
  return <img {...props} />;
}
