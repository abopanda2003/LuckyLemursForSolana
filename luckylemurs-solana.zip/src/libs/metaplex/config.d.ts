export declare const config: {
    arweaveWallet: string;
    programs: {
        auction: string;
        metadata: string;
        metaplex: string;
        vault: string;
        memo: string;
    };
};
