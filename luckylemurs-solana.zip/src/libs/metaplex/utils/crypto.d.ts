/// <reference types="node" />
import { Buffer } from 'buffer';
export declare const getFileHash: (file: Buffer) => Promise<Buffer>;
